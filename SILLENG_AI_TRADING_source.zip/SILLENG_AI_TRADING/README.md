# SILLENG AI TRADING — Android starter

Selected configuration:
- Android APK
- Java 17 / Gradle 8.9-compatible Android Gradle Plugin 8.7.3
- Gemini AI (`gemini-2.5-flash`)
- TradingView Lightweight Charts in Android WebView
- AI signals only; no order execution

## Current limitations
1. The chart contains sample candles, not live XAUUSD data.
2. The AI analyzes those sample candles only. Do not trade from this demo.
3. The Gemini key is entered locally at runtime and is not saved. A key embedded in a distributed APK can still be extracted; production use should proxy Gemini calls through a secured backend.
4. The app does not claim to provide profitable or guaranteed signals.

## Build
Use JDK 17 and Android SDK 35. From this directory run:
```bash
gradle assembleDebug
```
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions workflow: `.github/workflows/build-apk.yml`.
