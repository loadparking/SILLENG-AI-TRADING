package com.silleng.aitrading;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView chart;
    private EditText apiKeyInput;
    private TextView status, signal;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final String MODEL = "gemini-2.5-flash";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10, 15, 28));
        getWindow().setNavigationBarColor(Color.rgb(10, 15, 28));
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView label(String text, int size) {
        TextView t = new TextView(this); t.setText(text); t.setTextColor(Color.WHITE);
        t.setTextSize(size); t.setPadding(dp(12), dp(8), dp(12), dp(8)); return t;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12), dp(12), dp(12), dp(18));
        page.setBackgroundColor(Color.rgb(10,15,28));
        scroll.addView(page);

        TextView title = label("SILLENG AI TRADING", 22);
        title.setGravity(Gravity.CENTER); title.setTypeface(null, 1); page.addView(title);
        TextView sub = label("XAUUSD  •  AI SIGNALS ONLY  •  M15", 12);
        sub.setGravity(Gravity.CENTER); sub.setTextColor(Color.LTGRAY); page.addView(sub);

        status = label("Chart status: DEMO candles (not live market data)", 12);
        status.setTextColor(Color.YELLOW); page.addView(status);

        chart = new WebView(this);
        chart.getSettings().setJavaScriptEnabled(true);
        chart.getSettings().setDomStorageEnabled(true);
        chart.setWebChromeClient(new WebChromeClient());
        chart.setWebViewClient(new WebViewClient());
        chart.loadUrl("file:///android_asset/chart.html");
        page.addView(chart, new LinearLayout.LayoutParams(-1, dp(300)));

        signal = label("AI signal: Not generated yet", 17);
        signal.setTypeface(null, 1); page.addView(signal);

        TextView guide = label("Gemini API key (keep it private; do not share it):", 13);
        page.addView(guide);
        apiKeyInput = new EditText(this);
        apiKeyInput.setSingleLine(true);
        apiKeyInput.setHint("Paste your Gemini API key");
        apiKeyInput.setHintTextColor(Color.GRAY);
        apiKeyInput.setTextColor(Color.WHITE);
        apiKeyInput.setInputType(0x00000081);
        apiKeyInput.setPadding(dp(12), dp(8), dp(12), dp(8));
        apiKeyInput.setBackgroundColor(Color.rgb(30,39,56));
        page.addView(apiKeyInput);

        Button analyse = new Button(this);
        analyse.setText("ANALYSE XAUUSD WITH GEMINI");
        page.addView(analyse);
        analyse.setOnClickListener(v -> runAnalysis());

        TextView note = label(
            "IMPORTANT: The chart currently uses sample candles. This starter does not fetch live XAUUSD prices. " +
            "Connect a licensed/reliable market-data feed before trusting any signal. AI output is educational, " +
            "not financial advice. No trades are placed by this app.", 12);
        note.setTextColor(Color.LTGRAY); page.addView(note);

        setContentView(scroll);
    }

    private void runAnalysis() {
        String key = apiKeyInput.getText().toString().trim();
        if (key.isEmpty()) {
            Toast.makeText(this, "Enter your Gemini API key first.", Toast.LENGTH_LONG).show();
            return;
        }
        signal.setText("AI signal: Analysing sample candles…");
        executor.execute(() -> {
            try {
                // Sample OHLC data only. Replace with verified live XAUUSD bars before real use.
                JSONArray candles = new JSONArray();
                double[] closes = {2368.2,2369.1,2367.8,2371.0,2373.4,2372.1,2375.2,2374.0,2377.3,2378.1};
                for (int i=0;i<closes.length;i++) {
                    JSONObject c = new JSONObject();
                    c.put("open", i==0 ? closes[i]-0.6 : closes[i-1]);
                    c.put("high", closes[i]+0.8);
                    c.put("low", closes[i]-0.7);
                    c.put("close", closes[i]);
                    candles.put(c);
                }
                String prompt = "You are a cautious XAUUSD market-analysis assistant. Analyze these SAMPLE M15 OHLC candles only. " +
                    "Return concise JSON with keys bias (BUY/SELL/WAIT), entry, stop_loss, take_profit, reasons, invalidation. " +
                    "If data is insufficient, bias must be WAIT. Do not invent current market prices. " +
                    "Explicitly state that these are sample candles, not live data. Candles: " + candles;
                JSONObject body = new JSONObject();
                JSONArray contents = new JSONArray();
                JSONObject content = new JSONObject();
                JSONArray parts = new JSONArray();
                JSONObject part = new JSONObject(); part.put("text", prompt); parts.put(part);
                content.put("parts", parts); contents.put(content); body.put("contents", contents);
                JSONObject generation = new JSONObject();
                generation.put("temperature", 0.2);
                generation.put("responseMimeType", "application/json");
                body.put("generationConfig", generation);

                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + MODEL + ":generateContent");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(20000); conn.setReadTimeout(30000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("x-goog-api-key", key);
                try (OutputStream out = conn.getOutputStream()) {
                    out.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                int code = conn.getResponseCode();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                    code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(), StandardCharsets.UTF_8));
                StringBuilder response = new StringBuilder(); String line;
                while ((line=reader.readLine())!=null) response.append(line);
                reader.close(); conn.disconnect();
                if (code < 200 || code >= 300) throw new Exception("Gemini HTTP " + code + ": " + response);
                JSONObject root = new JSONObject(response.toString());
                String result = root.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
                runOnUiThread(() -> signal.setText("AI SAMPLE ANALYSIS\n" + result));
            } catch (Exception e) {
                runOnUiThread(() -> signal.setText("Analysis error: " + e.getMessage()));
            }
        });
    }

    @Override public void onDestroy() {
        executor.shutdownNow();
        if (chart != null) chart.destroy();
        super.onDestroy();
    }
}
